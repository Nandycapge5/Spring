import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
private int empId;
private String empName;
private String empAddress;
private int empSal;
private Address add;

private TAddress tadd;


@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", empAddress=" + empAddress + ", empSal=" + empSal
			+ ", add=" + add + ", tadd=" + tadd + "]";
}

@Autowired
public Employee(int empId, String empName, String empAddress, int empSal, Address add, TAddress tadd) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empAddress = empAddress;
	this.empSal = empSal;
	this.add = add;
	this.tadd = tadd;
}


}
