
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {

		ApplicationContext c = new ClassPathXmlApplicationContext("DependentObject.xml");
		Employee ob = (Employee) c.getBean("e");

		System.out.println(ob);

	}

}
