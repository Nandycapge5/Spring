package com.cap.spring;

import java.util.Set;

public class Question {

	private int qid;
	private String name;
	private Set answers;
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set getAnswers() {
		return answers;
	}
	public void setAnswers(Set answers) {
		this.answers = answers;
	}
	
	void display()
	{
		System.out.println(this.qid+"   "+this.name);
		
		 for(Object o:answers)
	        {
	            System.out.println(o);
	        }
	}
}
