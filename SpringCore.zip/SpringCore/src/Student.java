
public class Student {
private int sid;
private String sname;
private int mark;
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public int getMark() {
	return mark;
}
public void setMark(int mark) {
	this.mark = mark;
}

void display()
{
	System.out.println(this.sid+" "+this.sname+" "+this.mark);
}
public Student(int sid, String sname, int mark) {
	super();
	this.sid = sid;
	this.sname = sname;
	this.mark = mark;
}
public Student() {
	super();
}
}
