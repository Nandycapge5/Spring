import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Resource r=new ClassPathResource("spring.xml");
		BeanFactory factory=new XmlBeanFactory(r);
		
		Student s2=(Student)factory.getBean("s");
		Student s3=(Student)factory.getBean("s1");
		s2.display();
		s3.display();


	}

}
