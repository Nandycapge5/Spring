package com.cap.spring.without.xml;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean("emp")
	public Employee getEmployee()
	{
		return new Employee();
		
	}
	
	
	
	
}
