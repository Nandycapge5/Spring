package com.web1;

import org.eclipse.jdt.internal.compiler.batch.Main;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

public class Test {
public static void main(String[] args) {
	/*Client c=Client.create();
	WebResource res=c.resource("http://localhost:2135/JAX_RS_JERSY_SERVICE/rest/welcomeService/xyz/nandy/20");
String res1=res.get(String.class);
System.out.println(res1);
*/
	
	Client c=Client.create();
	WebResource res=c.resource("http://localhost:2135/JAX_RS_JERSY_SERVICE/rest/welcomeService/xyz1?name1=nandy&age1=20");
String res1=res.get(String.class);
System.out.println(res1);


}
}
