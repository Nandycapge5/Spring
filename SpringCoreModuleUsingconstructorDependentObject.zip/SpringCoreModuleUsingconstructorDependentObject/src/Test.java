import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
public static void main(String[] args) {
	Resource r=new ClassPathResource("abc.xml");
	BeanFactory factory=new XmlBeanFactory(r);
	Person ob=(Person) factory.getBean("p1");

//Person ob1=(Person) factory.getBean("p1");
ob.display();
//ob1.display();

}
}
