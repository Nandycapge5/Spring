
public class Person {

	
	private int pid;
	private String pname;
	private String pcity;
	
	private Address add;
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add = add;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPcity() {
		return pcity;
	}
	public void setPcity(String pcity) {
		this.pcity = pcity;
	}
	void display()
	{
		System.out.println(this.pid+"  "+this.pname+" "+this.pcity+this.add);
	}
	
	@Override
	public String toString() {
		return "Person [pid=" + pid + ", pname=" + pname + ", pcity=" + pcity + ", add=" + add + "]";
	}
	public Person() {
		super();
	}
	public Person(int pid, String pname, String pcity) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pcity = pcity;
	}
	
	
}
