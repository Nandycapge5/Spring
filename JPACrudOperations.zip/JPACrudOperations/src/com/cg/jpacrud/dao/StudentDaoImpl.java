package com.cg.jpacrud.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.jpacrud.entities.Student;
@Repository
public class StudentDaoImpl implements StudentDao {
	@PersistenceContext
	private EntityManager entityManager;
 
	public void setEntityManager(EntityManager entityManager)
{
	this.entityManager = entityManager;
}
	/*public StudentDaoImpl() {
		
	}*/

	@Override
	public Student getStudentById(int id) {
		Student student = entityManager.find(Student.class, id);
		return student;
	}
     @Transactional
	@Override
	public void addStudent(Student student) {
		entityManager.persist(student);
	}
@Transactional
	@Override
	public void removeStudent(Student student) {
		entityManager.remove(student);
	}
@Transactional
	@Override
	public void updateStudent(Student student) {
		entityManager.merge(student);
	}

	
}
