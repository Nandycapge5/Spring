package com.web;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

@Path(value = "/welcomeService") //class level path
public class Welcome {

	@GET
	@Path(value = "/xyz/{name1}/{age1}")  //method level path
	public String display(@PathParam("name1")String name,@PathParam("age1") int age)
	{
		return "welcome ms:"+"  "+name+"   your age is "+"  " +age;
		
	}
	
	@GET
	@Path(value = "/xyz1")  //? &
	public String display1(@QueryParam("name1")String name,@QueryParam("age1") int age)
	{
		return "welcome ms:"+"  "+name+"   your age is" +"  " +age;
		
	}
}
