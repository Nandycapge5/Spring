package com.empcrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.cg.jpacrud.dao.StudentDao;
//import com.empcrud.entities.service;
import com.empcrud.dao.EmployeeDao;
import com.empcrud.dao.EmployeeDaoImpl;
import com.empcrud.entities.EmployeeCrud;
@Service
public class EmployeeServiceImpl implements EmployeeService {
 
	private EmployeeDao dao;
	@Autowired
	public void setStudentDao(EmployeeDao studentDao){
		this.dao=studentDao;
	}
	
	
 public EmployeeServiceImpl() {
     dao = new EmployeeDaoImpl();
 
 }
	@Override
	public int create(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		
		int empId=dao.create(employee);
		
		return empId;
		
	}

	@Override
	public EmployeeCrud find(int empId) {
		// TODO Auto-generated method stub
		EmployeeCrud Employee  = dao.find(empId);
		return Employee;
	}

	@Override
	public void update(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		
		dao.update(employee);
		
	}

	
	@Override
	public List ListTransaction() {
		// TODO Auto-generated method stub
		
	List l2=dao.ListTransaction();
		
		return l2;
		
	}


	@Override
	public void delete(int id3) {
	      
	       
	   dao.delete(id3);
	    }
		
	}


