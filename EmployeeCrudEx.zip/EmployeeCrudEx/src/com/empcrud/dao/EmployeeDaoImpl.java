package com.empcrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

//import com.empcrud.dao.JPAUtil;
import com.empcrud.entities.EmployeeCrud;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	@PersistenceContext
	private EntityManager entityManager;
 
	public void setEntityManager(EntityManager entityManager)
{
	this.entityManager = entityManager;
}

	
	
	
	
@Transactional
		@Override
	public int create(EmployeeCrud employee) {
	entityManager.persist(employee);
		return employee.getEmpId();
		// TODO Auto-generated method stub
		
	}
	@Override
	public EmployeeCrud find(int empId) {
		// TODO Auto-generated method stub
		EmployeeCrud e=entityManager.find(EmployeeCrud.class, empId);
		
		return e;
	}
@Transactional
	@Override
	public void update(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		entityManager.merge(employee);
		
	}
@Transactional
	@Override
	public void delete(int eid) {
		// TODO Auto-generated method stub
	EmployeeCrud e=entityManager.find(EmployeeCrud.class, eid);
		entityManager.remove(e);

	}
	
	



	@Override
	public EmployeeCrud getStudentById(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List ListTransaction() {
		// TODO Auto-generated method stub
		
		TypedQuery<EmployeeCrud> q2=entityManager.createQuery("select c from EmployeeCrud c",EmployeeCrud.class);
        List<EmployeeCrud> l1=q2.getResultList();

		return l1;

		
	}
	
}
