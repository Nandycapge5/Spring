package com.cap.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Resource r=new class
		
		Resource r=new ClassPathResource("ApplicationContext.xml");
		BeanFactory factory=new XmlBeanFactory(r);
	Employee ob=(Employee) factory.getBean("e");
	Employee ob1=(Employee) factory.getBean("e1");

		ob.display();
		ob1.display();

		
		

	}

}
