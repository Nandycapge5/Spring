

public class Employee {
private int empId;
private String empName;
private String empAddress;

private int empSal;
private Address add;
private TAddress tadd;

public TAddress getTadd() {
	return tadd;
}
public void setTadd(TAddress tadd) {
	this.tadd = tadd;
}


public Address getAdd() {
	return add;
}

public void setAdd(Address add) {
	this.add = add;
}

public Employee() {
	super();
}

/*public Employee(int empId, String empName, String empAddress, int empSal) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empAddress = empAddress;
	this.empSal = empSal;
}*/

public int getEmpId() {
	return empId;
}

public void setEmpId(int empId) {
	this.empId = empId;
}

public String getEmpName() {
	return empName;
}

public void setEmpName(String empName) {
	this.empName = empName;
}

public String getEmpAddress() {
	return empAddress;
}

public void setEmpAddress(String empAddress) {
	this.empAddress = empAddress;
}

public int getEmpSal() {
	return empSal;
}

public void setEmpSal(int empSal) {
	this.empSal = empSal;
}
public void display()
{
	System.out.println(getEmpId()+"  "+getEmpName()+" "+getEmpAddress()+" "+getEmpSal());
System.out.println(add);
System.out.println(tadd);


}

public Employee(int empId, String empName, String empAddress, int empSal, Address add, TAddress tadd) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empAddress = empAddress;
	this.empSal = empSal;
	this.add = add;
	this.tadd = tadd;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", empAddress=" + empAddress + ", empSal=" + empSal
			+ ", add=" + add + ", tadd=" + tadd + "]";
}


}
