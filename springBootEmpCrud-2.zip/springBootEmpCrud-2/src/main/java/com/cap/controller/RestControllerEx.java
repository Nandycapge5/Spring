package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.Employee;
import com.cap.service.EmployeeService;

@RestController
@RequestMapping("/Bank")
public class RestControllerEx {

	@Autowired
	EmployeeService empservice;
	@PostMapping("/createAccount")
public List<Employee> createAccount(@RequestBody Employee emp)
{
		return empservice.createEmployee(emp);
}
}
