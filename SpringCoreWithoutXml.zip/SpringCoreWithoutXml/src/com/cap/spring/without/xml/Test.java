package com.cap.spring.without.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext c=new ClassPathXmlApplicationContext("abc.xml");
		Employee e=(Employee)c.getBean("emp");
		e.setEid(25);
		e.setEname("manju");
		e.setEsal(56000);
		e.display();

	}

}
